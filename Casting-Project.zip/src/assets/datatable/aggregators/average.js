import averageOf from "../utilities/average-of";

export default {
    label: "Average",
    callback: averageOf,
    format: true
}