
export default {
    label: "Count",
    callback: (array) => array.length
}