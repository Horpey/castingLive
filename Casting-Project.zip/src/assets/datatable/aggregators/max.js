import maxOf from "../utilities/max-of";

export default {
    label: "Maximum",
    callback: maxOf,
    format: true
}