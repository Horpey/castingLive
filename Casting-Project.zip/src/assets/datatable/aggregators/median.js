import medianOf from "../utilities/median-of";

export default {
    label: "Median",
    callback: medianOf
}