import minOf from "../utilities/min-of";

export default {
    label: "Minimum",
    callback: minOf,
    format: true
}