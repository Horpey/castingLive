import standardDeviationOf from "../utilities/standard-deviation-of";

export default {
    label: "Standard Deviation",
    callback: standardDeviationOf
}