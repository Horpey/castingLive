import totalOf from "../utilities/total-of";

export default {
    label: "Total",
    callback: totalOf,
    format: true
}