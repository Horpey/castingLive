import varianceOf from "../utilities/variance-of";

export default {
    label: "Variance",
    callback: varianceOf
}