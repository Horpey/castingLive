# Toggles

This docucumentation will cover 3 components which all share the *toggle* behaviour