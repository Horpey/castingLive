import Drag from "./v-drag";

export default {
    drag: Drag
}