import currencies from "./currencies";

export default {
    currencies
}