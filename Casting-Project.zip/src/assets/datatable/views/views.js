import Components from "./components/components";

export default {
    components: Components
}