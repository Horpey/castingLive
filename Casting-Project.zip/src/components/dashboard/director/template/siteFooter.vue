<template>
    <div>
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        © 2018 Cast.i.ng All Rights Reserved.
                    </div>
                </div>
            </div>
        </footer>
    </div>
</template>

<script>
export default {
	name: 'siteFooter',
};
</script>

<style>
</style>