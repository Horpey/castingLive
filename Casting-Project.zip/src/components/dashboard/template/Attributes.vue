<template>
    <div>
        <h5 class="col-ppd">Attributes</h5>
        <b>Gender:</b>
        <span class="float-right">Male</span>
        <div class="bline"></div>
        <b>Height:</b>
        <span class="float-right">45</span>
        <div class="bline"></div>
        <b>Weight:</b>
        <span class="float-right">24</span>
        <div class="bline"></div>
        <b>Body Mass (in KG):</b>
        <span class="float-right">24</span>
        <div class="bline"></div>
        <b>Shirt Size (in Inches):</b>
        <span class="float-right">23 In</span>
        <div class="bline"></div>
        <b>Waist Size (in Inches):</b>
        <span class="float-right">23 In</span>

        <h5 class="col-ppd mt-5">Sizes</h5>
        <b>Trouser length (in Inches):</b>
        <span class="float-right">23 In</span>
        <div class="bline"></div>
        <b>Shoulder length (in Inches):</b>
        <span class="float-right">34 In</span>
        <div class="bline"></div>
        <b>Jacket size:</b>
        <span class="float-right">45</span>
        <div class="bline"></div>
        <b>Shoe Size:</b>
        <span class="float-right">46</span>
        <div class="bline"></div>     
    </div>
</template>

<script>
export default {
	name: 'Attributes',
};
</script>

<style>
</style>