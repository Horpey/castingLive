<template>
    <div>
        <nav>
            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                <a class="nav-item nav-link active" id="nav-auditions-tab" data-toggle="tab" href="#nav-auditions" role="tab" aria-controls="nav-home" aria-selected="true">All Auditions</a>
                <a class="nav-item nav-link" id="nav-my-auditions-tab" data-toggle="tab" href="#nav-my-auditions" role="tab" aria-controls="nav-my-auditions" aria-selected="false">My Auditions</a>
            </div>
        </nav>

    </div>
</template>

<script>
export default {
	name: 'auditiontab',
};
</script>

<style>
</style>