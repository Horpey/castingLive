<template>
    <div>
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand mt-2 mb-2">
                    <a href="#">
                        <img src="../../../assets/images/logo1.png">
                    </a>
                </li>
                <li>
                    <a href="dashboard.html">Dashboard</a>
                </li>
                <li>
                    <a href="auditions.html">Auditions</a>
                </li>
                <li class="active">
                    <a href="profile.html">My Profile</a>
                </li>
                <li>
                    <a href="photo.html">Photo Gallery</a>
                </li>
                <li>
                    <a href="video.html">Video</a>
                </li>
                <li>
                    <a href="audio.html">Audio</a>
                </li>
            </ul>
        </div>
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        © 2018 Cast.i.ng All Rights Reserved.
                    </div>
                </div>
            </div>
        </footer>
    </div>
</template>

<script>
export default {
	name: 'siteFooter',
};
</script>

<style>
</style>