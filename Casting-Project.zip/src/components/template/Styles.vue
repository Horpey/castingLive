<template>
    <div>

  </div>
</template>

<script>
export default {
	name: 'styles',
};
</script>

<style scoped>
@import '../../assets/vendor/bootstrap/css/bootstrap.min.css';
@import '../../assets/css/responsive.css';
@import '../../assets/css/main.css';
@import '../../assets/css/hover.css';
@import '../../assets/slick/slick.css';
@import '../../assets/slick/slick-theme.css';
@import '../../assets/css/timeline.css';
</style>